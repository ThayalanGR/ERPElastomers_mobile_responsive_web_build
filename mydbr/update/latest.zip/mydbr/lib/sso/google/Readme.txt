- Create Google OAuth 2.0 client ID
  https://console.developers.google.com/ -> Web application

- Define the connection variables Environmental Settings
  - SSO Server URL: URL to this directory's index.php
  - OAuth 2 Client ID
  - OAuth 2 Client Secret