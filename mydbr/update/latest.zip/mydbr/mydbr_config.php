<?php 
// myDBR configuration file. Created: 2009-09-22 12:04:55
define( "DB_VENDOR", 'mysql' );
define( "DB_HOST", 'localhost' );
define( "DB_PORT", 3306 );
define( "DB_NAME", 'mydbr' );
define( "DB_USER", 'root' );
define( "DB_PASSWORD", '' );
define( "SETUP_DONE", false );
